package com.programs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ManageCourse {
	// set connection requirement
	private static Connection conn;
	private static PreparedStatement pst;
	private static ResultSet rs;
	static Scanner sc=new Scanner(System.in);

	public static void manageCourse() throws SQLException {
		conn=DatabaseConnection.getConnection();
	
		while(true) {
			System.out.println("1.Add New Course      2.Update Course");
			System.out.println("3.Delete Course       4.Show All Course");
			System.out.println("Enter Your Choice");
			int ch=sc.nextInt();
			
			switch(ch) {
			case 1:
				  System.out.println("Add New Course");
				  addnewCourse();
				  break;
			case 2:
				  System.out.println("Update Course");
				  updateCourse();
				  break;
			case 3:
				  System.out.println("Delete Course");
				  deleteCourse();
				  break;
			case 4:
				  System.out.println("Show All Course");
				  showCourse();
				  break;
			default:
				  System.out.println("Enter Valid choice");
			}
			System.out.println("Do You Want To Continue press y/n");
			char choice=sc.next().charAt(0);
			if(choice=='n') {
				break;
			}
		}
		
	}
	
	// update Course
	
	private static void updateCourse() {
		try {
			while(true) {
				System.out.println("1.Update Cname");
				System.out.println("2.Update Fees");
				System.out.println("Enter Your Choice");
				int ch=sc.nextInt();
				
				switch(ch) {
				case 1:
					  System.out.println("Enter CID");
					  int cid=sc.nextInt();
					  String s="select * from course where cid=?";
					  pst=conn.prepareStatement(s);
					  pst.setInt(1, cid);
					  rs=pst.executeQuery();
					  if(rs.next()) {
						  System.out.println("Enter Cname");
						  String cname=sc.next();
						  String s1="update course set cname=? where cid=?";
						  pst=conn.prepareStatement(s1);
						  pst.setString(1, cname);
						  pst.setInt(2, cid);
						  int i=pst.executeUpdate();
						  if(i>0) {
							  System.out.println("Course Name Update.");
						  }else {
							  System.out.println("Course Name Not Update");
						  }
					  }
					  break;
				case 2:
					  System.out.println("Enter CID");
					  int cid1=sc.nextInt();
					  String s1="select * from course where cid=?";
					  pst=conn.prepareStatement(s1);
					  pst.setInt(1, cid1);
					  rs=pst.executeQuery();
					  if(rs.next()) {
						  System.out.println("Enter Cfees");
						  float cfees=sc.nextFloat();
						  String s2="update course set cfees=? where cid=?";
						  pst=conn.prepareStatement(s2);
						  pst.setFloat(1, cfees);
						  pst.setInt(2, cid1);
						  int i=pst.executeUpdate();
						  if(i>0) {
							  System.out.println("Course Fees Update.");
						  }else {
							  System.out.println("Course Fees Not Update");
						  }
					  }
					  break;
				default:
					  System.out.println("Enter Valid Choice");
				}
				
				System.out.println("Do You Want To Contiune press y/n");
				char cho=sc.next().charAt(0);
				if(cho=='n') {
					break;
				}
				
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	// Delete Course
	private static void deleteCourse() throws SQLException {
		try {
			conn=DatabaseConnection.getConnection();
			System.out.println("Are You Sure To Delete Student Press y/n");
			char ch=sc.next().charAt(0);
			if(ch=='n') {
				
			}else {
				System.out.println("Enter Course ID");
				int cid=sc.nextInt();
				
				String s="select * from course where cid=?";
				pst=conn.prepareStatement(s);
				pst.setInt(1, cid);
				rs=pst.executeQuery();
				if(rs.next()) {
					String del="delete from course where cid=?";
					pst=conn.prepareStatement(del);
					pst.setInt(1, cid);
					int result=pst.executeUpdate();
					if(result>0) {
						System.out.println("Course Deleted.");
					}else {
						System.out.println("Course Not Delete.");
					}
				}else {
					System.out.println("Course ID Not Found.");
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}

		
		
	}
	// Add New Course

	private static void addnewCourse() throws SQLException {
		int cid=0;
	   String s="select max(cid) from course";
		   pst=conn.prepareStatement(s);
		   rs=pst.executeQuery();
		   if(rs.next()) {
			   cid=rs.getInt(1)+1;
		   }else {
			   System.out.println("Record Not fetch error occure");
		   }
		   System.out.println("Enter Course Name");
		   String cname=sc.next();
		   
		   String c="select * from course where cname=?";
		   pst=conn.prepareStatement(c);
		   pst.setString(1, cname);
		   rs=pst.executeQuery();
		   if(rs.next()) {
			   System.out.println("Course Already Register");
		   }
		   else {
			   System.out.println("Enter Course Fees");
			   float cfees=sc.nextFloat();
			   
			   String ins="insert into course values(?,?,?)";
			   pst=conn.prepareStatement(ins);
			   pst.setInt(1, cid);
			   pst.setString(2, cname);
			   pst.setFloat(3, cfees);
			   int i=pst.executeUpdate();
			   if(i>0) {
				   System.out.println("Course Register.");
			   }else {
				   System.out.println("Course Not Register.");
			   }
		   }
		   
		   
		
	}

	// Show All Course
	private static void showCourse() throws SQLException {
		String course="select * from course";
		   pst=conn.prepareStatement(course);
		   rs=pst.executeQuery();
		   System.out.printf("%-6s%-20s%6s\n","CID","CNAME","CFEES");
		   System.out.println("----------------------------------");
		   while(rs.next()) {
			  System.out.printf("%-6s%-20s%6s\n",rs.getInt(1),rs.getString(2),rs.getFloat(3));
		   }
		
	}

}
